from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'aod_zeroBias_20_04_2026'
config.section_('JobType')
config.JobType.psetName = 'runReco_ZeroBias.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 3000
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.inputDataset = '/ZeroBias/HIRun2018A-v1/RAW'
config.Data.allowNonValidInputDataset = True
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.ignoreLocality = True
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'aod_zeroBias_20_04_2026'
config.Data.outLFNDirBase = '/store/group/phys_diffraction/lbyl_2018/HIZeroBias/reco_20_04_2026/'
config.Data.runRange = '326294-327802'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T1_*']
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
