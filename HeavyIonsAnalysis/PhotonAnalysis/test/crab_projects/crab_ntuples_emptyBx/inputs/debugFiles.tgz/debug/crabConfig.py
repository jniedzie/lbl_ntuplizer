from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'ntuples_emptyBx'
config.section_('JobType')
config.JobType.psetName = 'runForestAOD_pponAA_EMPTYBX_103X.py'
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.inputDataset = '/HIEmptyBX/HIRun2018A-27Feb2019-v1/AOD'
config.Data.allowNonValidInputDataset = True
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.ignoreLocality = True
config.Data.splitting = 'FileBased'
config.Data.lumiMask = '/afs/cern.ch/cms/CAF/CMSCOMM/COMM_DQM/certification/Collisions18/HI/PromptReco/Cert_326381-327564_HI_PromptReco_Collisions18_JSON.txt'
config.Data.outputDatasetTag = 'ntuples_emptyBx'
config.Data.outLFNDirBase = '/store/group/phys_diffraction/lbyl_2018/HIEmptyBX/ntuples_3_11_2026/'
config.Data.runRange = '326381-327564'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T1_*']
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
